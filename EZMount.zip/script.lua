-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

local mount = require("EZMount")

local armortex = {
	iron = textures["iron"],
	diamond = textures["diamond"],
	golden = textures["gold"],
	leather = textures["leather"]
}

local armorcubes = {
	models.horse.Horse.front.stirrup
}

local saddlecubes = {
	models.horse.Horse.Saddle,
}

local bagcubes = {
	models.horse.Horse.Bags
}

local headcubes = {
	models.horse.Horse.front,
}

local thing = animations.horse

local animlist = {
	still = thing.still,
	forward = thing.forward,
	backward = thing.backward,
	turnright = thing.turnright,
	turnleft = thing.turnleft,
	up = thing.jump,
	down = thing.down,
	rear = thing.rear,
	gallop = thing.gallop
}

local boat = animations.boat

local boatList = {
	["still"] = boat.still,
	["forward"] = boat.forward,
	["backward"] = boat.backward,
	["turnright"] = boat.turnright,
	["turnleft"] = boat.turnleft,
	["up"] = boat.up,
	["down"] = boat.down,
	["rear"] = boat.rear,
}

local minecart = animations.minecart

local minecartList = {
	["still"] = minecart.still,
	["forward"] = minecart.forward,
	["backward"] = minecart.backward,
	["turnright"] = minecart.turnright,
	["turnleft"] = minecart.turnleft,
	["up"] = minecart.up,
	["down"] = minecart.down,
	["rear"] = minecart.rear,
}

local passengercubes = {
	models.horse.Horse.TailA
}

mount:newLivingMount("horse",models.horse,headcubes,saddlecubes,bagcubes,armorcubes,armortex,passengercubes,animlist)
--mount:newLivingMount("mule",models.horse,headcubes,saddlecubes,bagcubes,armorcubes,armortex,animlist)
mount:newObjectMount("boat",models.boat,passengercubes,boatList)
mount:newObjectMount("minecart",models.minecart,passengercubes,minecartList)